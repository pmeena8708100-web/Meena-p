THE CHAI SHOP & CO. - CRM APPLICATION

Technology:
- Python
- Flask
- SQLite
- HTML/CSS

HOW TO RUN ON WINDOWS

1. Install Python.
2. Open Command Prompt or the VS Code terminal.
3. Go to this project folder.
4. Install Flask:
   pip install -r requirements.txt
5. Run:
   python app.py
6. Open the address shown in the terminal, normally:
   http://127.0.0.1:5000

The SQLite database (chai_shop.db) is created automatically the first time the app runs.

FEATURES
- CRM dashboard
- Customer management
- Menu/product display
- Order management
- Loyalty points
- Customer feedback
- Sales and customer reports

PROJECT STRUCTURE
app.py              Main Flask application
chai_shop.db        SQLite database (created automatically)
requirements.txt    Python dependency
templates/          HTML pages
static/             CSS styling
README.txt          Setup instructions
